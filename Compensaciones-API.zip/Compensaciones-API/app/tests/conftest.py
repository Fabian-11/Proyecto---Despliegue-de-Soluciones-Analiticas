from typing import Generator

import pandas as pd
import pytest
from fastapi.testclient import TestClient

from app.main import app


# Datos de prueba para el modelo de compensaciones
@pytest.fixture(scope="module")
def test_data() -> pd.DataFrame:
    # Un solo registro de ejemplo con las variables de entrada del modelo
    data = [
        {
            "DIUG": 15.6,
            "FIUG": 15.6,
            "CEC": 20.8,
            "VCD": 915.4,
            "VCF": 597.4,
            "GRUPO_CALIDAD_x": 12,
            "NIVEL_TENSION_x": 2,
            "CARGO_DISTRIBUCION": 395.4,
            "CONSUMO_MES": 199.3,
            "MES_FACTURADOS": 1,
            "%_PROP._ACTIVO": 100.0,
            # IMPORTANTE: no incluimos COMPENSADO porque es la variable objetivo
            # y la API solo debe recibir variables de entrada para la predicción.
        }
    ]
    return pd.DataFrame(data)


# Cliente de prueba
@pytest.fixture()
def client() -> Generator:
    with TestClient(app) as _client:
        yield _client
        app.dependency_overrides = {}