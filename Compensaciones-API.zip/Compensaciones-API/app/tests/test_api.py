import numpy as np
import pandas as pd
from fastapi.testclient import TestClient


def test_make_prediction(client: TestClient, test_data: pd.DataFrame) -> None:
    # Given
    payload = {
        # ensure pydantic plays well with np.nan
        "inputs": test_data.replace({np.nan: None}).to_dict(orient="records")
    }

    # When
    response = client.post(
        "/api/v1/predict",
        json=payload,
    )

    # Then
    assert response.status_code == 200
    prediction_data = response.json()

    # Validación genérica para el modelo de compensaciones
    assert "predictions" in prediction_data
    assert "errors" in prediction_data

    # Debe haber predicciones y no debe haber errores
    assert prediction_data["predictions"] is not None
    assert prediction_data["errors"] is None

    # Debe ser una lista de la misma longitud que el conjunto de prueba
    assert isinstance(prediction_data["predictions"], list)
    assert len(prediction_data["predictions"]) == len(test_data)

    # Opcional: verificar que las predicciones sean numéricas (0/1, probas, montos, etc.)
    for p in prediction_data["predictions"]:
        assert isinstance(p, (int, float))