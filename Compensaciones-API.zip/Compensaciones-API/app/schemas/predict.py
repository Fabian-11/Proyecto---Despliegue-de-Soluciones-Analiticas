from typing import Any, List, Optional

from pydantic import BaseModel
from model.processing.validation import DataInputSchema

# Esquema de los resultados de predicción
class PredictionResults(BaseModel):
    errors: Optional[Any]
    version: str
    predictions: Optional[List[float]]

# Esquema para inputs múltiples
class MultipleDataInputs(BaseModel):
    inputs: List[DataInputSchema]

    class Config:
        schema_extra = {
            "example": {
                "inputs": [
                    {
                        # Variables presentes en la base
                        "DIUG": 8.8,
                        "FIUG": 15.6,
                        "CEC": 20.8,
                        "VCD": 915.4,
                        "VCF": 597.4,
                        "GRUPO_CALIDAD_x": 12,
                        "NIVEL_TENSION_x": 2,
                        "CARGO_DISTRIBUCION": 395.4,
                        "CONSUMO_MES": 199.3,
                        "MES_FACTURADOS": 1,
                        "%_PROP._ACTIVO": 100.0
                        # Nota: COMPENSADO es la variable objetivo,
                        # por lo tanto NO se envía en el request de predicción.
                    }
                ]
            }
        }