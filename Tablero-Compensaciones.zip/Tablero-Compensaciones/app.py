from dash import Dash, dcc, html, Output, Input, State
import plotly.express as px
import pandas as pd
import numpy as np
import requests
import json
import os

# =========================
# 0) CONFIGURACIÓN API
# =========================
# Debes exportar API_URL con la IP de la instancia donde está la API de compensaciones, por ejemplo:
# export API_URL=3.91.52.72
API_HOST = os.getenv("API_URL")
if API_HOST is None:
    # Para desarrollo local puedes poner algo como "127.0.0.1"
    API_HOST = "100.27.217.17"

API_PREDICT_URL = f"http://{API_HOST}:8001/api/v1/predict"

# =========================
# 1) CARGA Y PREPARACIÓN
# =========================
# Archivo con la base ya procesada de compensaciones para el tablero
# Asegúrate de que el archivo esté en la misma carpeta que app.py
# y se llame exactamente: base_balanceada_mod_final_dash.csv
df = pd.read_csv("base_balanceada_mod_final_dash.csv")
df = df.drop_duplicates()
# Validar columnas mínimas
required = {"NIU", "PERIODO", "COMPENSADO", "LATITUD", "LONGITUD"}
missing = list(required - set(df.columns))
if missing:
    raise ValueError(f"Faltan columnas obligatorias: {missing}")

df = df.copy()

# PERIODO_STR como YYYY-MM (ajusta si PERIODO viene en otro formato)
df["PERIODO_STR"] = df["PERIODO"].astype(str).str.slice(0, 7)
df["COMPENSADO"] = df["COMPENSADO"].astype(int)

# Variables opcionales
has_diug = "DIUG" in df.columns
has_consumo = "CONSUMO_MES" in df.columns

# KPI DIUG global
diug_prom_global = float(df["DIUG"].mean()) if has_diug and df["DIUG"].notna().any() else None

# =========================
# 2) SIMULACIÓN DE MODELO PARA TABLERO
# =========================
np.random.seed(42)
df["PROB_PRED"] = (
    df["COMPENSADO"] * np.random.uniform(0.55, 0.95, size=len(df))
    + (1 - df["COMPENSADO"]) * np.random.uniform(0.05, 0.45, size=len(df))
)
AUC_SIMULADO = 0.98

# =========================
# 3) FUNCIONES AUXILIARES
# =========================
def make_df_mes(comp_sel, d):
    """
    Devuelve un DataFrame con el conteo de registros por PERIODO_STR.
    Si comp_sel != "all", filtra por la etiqueta/predicción de COMP_PLOT.
    """
    if comp_sel != "all":
        d = d[d["COMP_PLOT"] == int(comp_sel)]
    return (
        d.groupby("PERIODO_STR", as_index=False)
        .size()
        .rename(columns={"size": "conteo"})
        .sort_values("PERIODO_STR")
    )

# =========================
# 4) DASH APP
# =========================
app = Dash(__name__)
server = app.server  # <- necesario para gunicorn / Procfile

PRIMARY = "#1e4aa8"
CARD = {
    "border": "1px solid #e5e7eb",
    "borderRadius": "12px",
    "background": "#fff",
    "padding": "14px",
    "boxShadow": "0 1px 2px rgba(16,24,40,0.04)",
}
KPI_CARD = {
    "backgroundColor": PRIMARY,
    "color": "white",
    "borderRadius": "12px",
    "padding": "16px",
    "boxShadow": "0 2px 10px rgba(0,0,0,0.08)",
    "display": "flex",
    "flexDirection": "column",
    "gap": "6px",
    "height": "100%",
}
KPI_LABEL = {"fontSize": "13px", "opacity": 0.95}
KPI_VALUE = {"fontSize": "28px", "fontWeight": "800", "lineHeight": "1"}
WRAP = {
    "display": "grid",
    "gridTemplateColumns": "300px 1fr",
    "gap": "16px",
    "alignItems": "start",
}
HEADER = {
    "background": PRIMARY,
    "color": "white",
    "padding": "20px",
    "borderRadius": "14px",
    "marginBottom": "14px",
    "boxShadow": "0 4px 8px rgba(2,6,23,0.15)",
}

periodos = sorted(df["PERIODO_STR"].unique().tolist())
periodo_options = [{"label": "Todos", "value": "all"}] + [
    {"label": p, "value": p} for p in periodos
]

# =========================
# 5) LAYOUT
# =========================
app.layout = html.Div(
    style={
        "fontFamily": "Inter, Arial, sans-serif",
        "padding": "16px",
        "background": "#f6f7fb",
    },
    children=[
        # HEADER
        html.Div(
            style=HEADER,
            children=[
                html.H1(
                    "Predicción y Proyección de Compensaciones",
                    style={"margin": 0, "fontWeight": 800},
                ),
                html.Div(
                    "Tablero operativo para monitorear el conteo de casos compensados, "
                    "su distribución geográfica y el comportamiento por período. "
                    "Permite contrastar etiqueta real vs. predicción de modelo.",
                    style={"opacity": 0.95, "marginTop": "6px"},
                ),
            ],
        ),

        # CONTENEDOR PRINCIPAL
        html.Div(
            style=WRAP,
            children=[
                # ----- Sidebar -----
                html.Div(
                    style=CARD,
                    children=[
                        html.H4(
                            "Filtros",
                            style={"marginTop": 0, "marginBottom": "10px"},
                        ),
                        html.Label(
                            "Periodo (YYYY-MM)", style={"fontWeight": 600}
                        ),
                        dcc.Dropdown(
                            id="filtro_periodo",
                            options=periodo_options,
                            value="all",
                            clearable=False,
                        ),
                        html.Label(
                            "Fuente de estado",
                            style={
                                "fontWeight": 600,
                                "marginTop": "12px",
                            },
                        ),
                        dcc.RadioItems(
                            id="modo_comp",
                            options=[
                                {"label": "Etiqueta real", "value": "real"},
                                {"label": "Predicción (modelo)", "value": "pred"},
                            ],
                            value="real",
                            labelStyle={
                                "display": "block",
                                "marginBottom": "6px",
                            },
                            inputStyle={"marginRight": "6px"},
                        ),
                        html.Label(
                            "Umbral (solo predicción)",
                            style={
                                "fontWeight": 600,
                                "marginTop": "8px",
                            },
                        ),
                        dcc.Slider(
                            id="umbral",
                            min=0,
                            max=1,
                            step=0.01,
                            value=0.5,
                            marks={
                                0: "0",
                                0.25: "0.25",
                                0.5: "0.5",
                                0.75: "0.75",
                                1: "1",
                            },
                            tooltip={"placement": "bottom"},
                        ),
                        html.Hr(),
                        html.Label(
                            "Compensado", style={"fontWeight": 600}
                        ),
                        dcc.RadioItems(
                            id="filtro_comp",
                            options=[
                                {"label": "Todos", "value": "all"},
                                {"label": "No (0)", "value": 0},
                                {"label": "Sí (1)", "value": 1},
                            ],
                            value="all",
                            labelStyle={"display": "block"},
                            inputStyle={"marginRight": "6px"},
                        ),
                        html.Hr(),
                        html.Label(
                            "Indicador DIUG (promedio global)",
                            style={"fontWeight": 600},
                        ),
                        html.Div(
                            style={
                                **CARD,
                                "background": PRIMARY,
                                "color": "white",
                                "textAlign": "center",
                                "padding": "16px",
                                "border": "0",
                                "boxShadow": "inset 0 0 0 1px rgba(255,255,255,.08)",
                            },
                            children=[
                                html.Div(
                                    "DIUG promedio",
                                    style={
                                        "fontSize": "14px",
                                        "opacity": 0.9,
                                    },
                                ),
                                html.Div(
                                    f"{diug_prom_global:.2f}"
                                    if diug_prom_global is not None
                                    else "N/D",
                                    style={
                                        "fontSize": "36px",
                                        "fontWeight": 800,
                                        "lineHeight": "1.2",
                                    },
                                ),
                                html.Div(
                                    "kWh",
                                    style={
                                        "fontSize": "12px",
                                        "opacity": 0.85,
                                        "marginTop": "4px",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),

                # ----- Contenido principal (gráficos + formulario de predicción) -----
                html.Div(
                    children=[
                        # KPIs
                        html.Div(
                            style={
                                "display": "grid",
                                "gridTemplateColumns": "1fr 1fr 1fr 1fr",
                                "gap": "16px",
                                "marginBottom": "16px",
                            },
                            children=[
                                html.Div(
                                    style=KPI_CARD,
                                    children=[
                                        html.Div(
                                            "Total registros", style=KPI_LABEL
                                        ),
                                        html.Div(
                                            f"{len(df):,}".replace(
                                                ",", "."
                                            ),
                                            style=KPI_VALUE,
                                        ),
                                    ],
                                ),
                                html.Div(
                                    style=KPI_CARD,
                                    children=[
                                        html.Div(
                                            "Períodos", style=KPI_LABEL
                                        ),
                                        html.Div(
                                            f"{len(periodos)}",
                                            style=KPI_VALUE,
                                        ),
                                    ],
                                ),
                                html.Div(
                                    style=KPI_CARD,
                                    children=[
                                        html.Div(
                                            "Compensados (1)",
                                            style=KPI_LABEL,
                                        ),
                                        html.Div(
                                            f"{int((df['COMPENSADO'] == 1).sum()):,}".replace(
                                                ",", "."
                                            ),
                                            style=KPI_VALUE,
                                        ),
                                    ],
                                ),
                                html.Div(
                                    style=KPI_CARD,
                                    children=[
                                        html.Div(
                                            "AUC Modelo",
                                            style=KPI_LABEL,
                                        ),
                                        html.Div(
                                            f"{AUC_SIMULADO}",
                                            style=KPI_VALUE,
                                        ),
                                    ],
                                ),
                            ],
                        ),

                        # Mapa
                        html.Div(
                            style=CARD,
                            children=[
                                html.H4(
                                    "Mapa de Probabilidades / Compensaciones",
                                    style={"marginTop": 0},
                                ),
                                dcc.Graph(
                                    id="grafico_mapa",
                                    style={"height": "540px"},
                                ),
                            ],
                        ),

                        # Línea
                        html.Div(
                            style=CARD,
                            children=[
                                html.H4(
                                    "Conteo por PERIODO (YYYY-MM)",
                                    style={"marginTop": 0},
                                ),
                                dcc.Graph(
                                    id="grafico_linea",
                                    style={"height": "360px"},
                                ),
                            ],
                        ),

                        # ----- FORMULARIO DE PREDICCIÓN (DEBAJO DE TODO) -----
                        html.Div(
                            style={**CARD, "marginTop": "18px"},
                            children=[
                                html.H3(
                                    "Simulador de predicción de compensación",
                                    style={"marginTop": 0},
                                ),
                                html.P(
                                    "Ingresa los valores de las variables clave para enviar una solicitud a la API "
                                    "de Compensaciones y obtener la probabilidad / clasificación.",
                                    style={"fontSize": "14px", "opacity": 0.85},
                                ),
                                html.Br(),

                                # Fila 1
                                html.Div(
                                    style={
                                        "display": "grid",
                                        "gridTemplateColumns": "1fr 1fr 1fr",
                                        "gap": "10px",
                                    },
                                    children=[
                                        html.Div(
                                            children=[
                                                html.Label("DIUG"),
                                                dcc.Input(
                                                    id="input_diug",
                                                    type="number",
                                                    value=15.6,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("FIUG"),
                                                dcc.Input(
                                                    id="input_fiug",
                                                    type="number",
                                                    value=15.6,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("CEC"),
                                                dcc.Input(
                                                    id="input_cec",
                                                    type="number",
                                                    value=20.8,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                    ],
                                ),
                                html.Br(),

                                # Fila 2
                                html.Div(
                                    style={
                                        "display": "grid",
                                        "gridTemplateColumns": "1fr 1fr 1fr",
                                        "gap": "10px",
                                    },
                                    children=[
                                        html.Div(
                                            children=[
                                                html.Label("VCD"),
                                                dcc.Input(
                                                    id="input_vcd",
                                                    type="number",
                                                    value=915.4,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("VCF"),
                                                dcc.Input(
                                                    id="input_vcf",
                                                    type="number",
                                                    value=597.4,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("CARGO_DISTRIBUCION"),
                                                dcc.Input(
                                                    id="input_cargo",
                                                    type="number",
                                                    value=395.4,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                    ],
                                ),
                                html.Br(),

                                # Fila 3
                                html.Div(
                                    style={
                                        "display": "grid",
                                        "gridTemplateColumns": "1fr 1fr 1fr",
                                        "gap": "10px",
                                    },
                                    children=[
                                        html.Div(
                                            children=[
                                                html.Label("GRUPO_CALIDAD_x"),
                                                dcc.Input(
                                                    id="input_grupo_calidad",
                                                    type="number",
                                                    value=12,
                                                    step=1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("NIVEL_TENSION_x"),
                                                dcc.Input(
                                                    id="input_nivel_tension",
                                                    type="number",
                                                    value=2,
                                                    step=1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("CONSUMO_MES"),
                                                dcc.Input(
                                                    id="input_consumo_mes",
                                                    type="number",
                                                    value=199.3,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                    ],
                                ),
                                html.Br(),

                                # Fila 4
                                html.Div(
                                    style={
                                        "display": "grid",
                                        "gridTemplateColumns": "1fr 1fr",
                                        "gap": "10px",
                                    },
                                    children=[
                                        html.Div(
                                            children=[
                                                html.Label("MES_FACTURADOS"),
                                                dcc.Input(
                                                    id="input_mes_fact",
                                                    type="number",
                                                    value=1,
                                                    step=1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                        html.Div(
                                            children=[
                                                html.Label("%_PROP._ACTIVO"),
                                                dcc.Input(
                                                    id="input_prop_activo",
                                                    type="number",
                                                    value=100.0,
                                                    step=0.1,
                                                    style={"width": "100%"},
                                                ),
                                            ]
                                        ),
                                    ],
                                ),

                                html.Br(),
                                html.Button(
                                    "Calcular predicción",
                                    id="btn_predict",
                                    n_clicks=0,
                                    style={
                                        "backgroundColor": PRIMARY,
                                        "color": "white",
                                        "border": "none",
                                        "padding": "10px 18px",
                                        "borderRadius": "8px",
                                        "cursor": "pointer",
                                        "fontWeight": 600,
                                    },
                                ),
                                html.Div(
                                    id="pred_output",
                                    style={
                                        "marginTop": "12px",
                                        "fontWeight": 600,
                                        "fontSize": "15px",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
            ],
        ),
    ],
)

# =========================
# 6) CALLBACKS
# =========================
@app.callback(
    Output("grafico_linea", "figure"),
    Output("grafico_mapa", "figure"),
    Input("filtro_periodo", "value"),
    Input("modo_comp", "value"),
    Input("umbral", "value"),
    Input("filtro_comp", "value"),
)
def actualizar(periodo_sel, modo_comp, thr, comp_sel):
    d = df.copy()

    # Modo: real vs predicción
    if modo_comp == "pred":
        d["COMP_PLOT"] = (d["PROB_PRED"] >= float(thr)).astype(int)
    else:
        d["COMP_PLOT"] = d["COMPENSADO"]

    # Filtros
    if periodo_sel != "all":
        d = d[d["PERIODO_STR"] == periodo_sel]
    if comp_sel != "all":
        d = d[d["COMP_PLOT"] == int(comp_sel)]

    # --- Gráfico de línea ---
    d_line = make_df_mes(comp_sel, d)
    fig_line = px.line(
        d_line,
        x="PERIODO_STR",
        y="conteo",
        markers=True,
        text="conteo",
        labels={
            "PERIODO_STR": "Periodo (YYYY-MM)",
            "conteo": "Cantidad",
        },
        title="Conteo por PERIODO (YYYY-MM)",
    )
    fig_line.update_traces(
        line=dict(width=3, color=PRIMARY),
        texttemplate="%{text:,}",
        textposition="top center",
    )
    fig_line.update_layout(
        yaxis=dict(tickformat=","),
        xaxis=dict(
            type="category",
            categoryorder="array",
            categoryarray=d_line["PERIODO_STR"].tolist(),
        ),
        margin=dict(l=30, r=20, t=50, b=40),
    )

    # --- Mapa ---
    if d.empty:
        fig_map = px.scatter_mapbox(lat=[], lon=[])
        fig_map.update_layout(
            mapbox_style="open-street-map",
            title="Mapa (sin datos)",
            margin=dict(l=10, r=10, t=50, b=10),
        )
    else:
        if modo_comp == "pred":
            fig_map = px.scatter_mapbox(
                d,
                lat="LATITUD",
                lon="LONGITUD",
                color="PROB_PRED",
                size="PROB_PRED",
                hover_data=["NIU", "PERIODO_STR", "PROB_PRED"],
                color_continuous_scale="YlOrRd",
                zoom=9,
                title=f"Predicción modelo (umbral={thr:.2f})",
            )
        else:
            fig_map = px.scatter_mapbox(
                d,
                lat="LATITUD",
                lon="LONGITUD",
                color=d["COMP_PLOT"].astype(str),
                hover_data=["NIU", "PERIODO_STR", "COMP_PLOT"],
                zoom=9,
                title=(
                    "Etiqueta real — PERIODO="
                    f"{periodo_sel if periodo_sel != 'all' else 'Todos'}"
                ),
            )

        fig_map.update_layout(
            mapbox_style="open-street-map",
            mapbox_center={
                "lat": float(d["LATITUD"].mean()),
                "lon": float(d["LONGITUD"].mean()),
            },
            margin=dict(l=10, r=10, t=50, b=10),
        )

    return fig_line, fig_map


@app.callback(
    Output("pred_output", "children"),
    Input("btn_predict", "n_clicks"),
    State("input_diug", "value"),
    State("input_fiug", "value"),
    State("input_cec", "value"),
    State("input_vcd", "value"),
    State("input_vcf", "value"),
    State("input_grupo_calidad", "value"),
    State("input_nivel_tension", "value"),
    State("input_cargo", "value"),
    State("input_consumo_mes", "value"),
    State("input_mes_fact", "value"),
    State("input_prop_activo", "value"),
    prevent_initial_call=True,
)
def hacer_prediccion(
    n_clicks,
    diug,
    fiug,
    cec,
    vcd,
    vcf,
    grupo_calidad,
    nivel_tension,
    cargo,
    consumo_mes,
    mes_fact,
    prop_activo,
):
    # Construir payload con SOLO las variables indicadas
    payload = {
        "inputs": [
            {
                "DIUG": float(diug),
                "FIUG": float(fiug),
                "CEC": float(cec),
                "VCD": float(vcd),
                "VCF": float(vcf),
                "GRUPO_CALIDAD_x": float(grupo_calidad),
                "NIVEL_TENSION_x": float(nivel_tension),
                "CARGO_DISTRIBUCION": float(cargo),
                "CONSUMO_MES": float(consumo_mes),
                "MES_FACTURADOS": int(mes_fact),
                "%_PROP._ACTIVO": float(prop_activo),
            }
        ]
    }

    headers = {"Content-Type": "application/json", "accept": "application/json"}

    try:
        resp = requests.post(
            API_PREDICT_URL, data=json.dumps(payload), headers=headers, timeout=10
        )
        resp.raise_for_status()
        data = resp.json()

        preds = data.get("predictions", [])
        if not preds:
            return "⚠️ La API respondió sin predicciones."

        valor = preds[0]
        # Aquí asumo que el modelo devuelve algo tipo probabilidad o 0/1
        etiqueta = "COMPENSADO (1)" if round(valor) == 1 else "NO COMPENSADO (0)"

        return f"Predicción modelo: {valor:.4f} → {etiqueta}"

    except Exception as e:
        return f"❌ Error al llamar la API: {e}"


# =========================
# 7) RUN
# =========================
if __name__ == "__main__":
    print(
        "🚀 Dash corriendo en http://0.0.0.0:8050 "
        f"(AUC={AUC_SIMULADO}, mapa + simulador de predicción)"
    )
    app.run_server(debug=False, host="0.0.0.0", port=8050)
