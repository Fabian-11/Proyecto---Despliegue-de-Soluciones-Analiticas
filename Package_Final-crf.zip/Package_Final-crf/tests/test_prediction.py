import numpy as np

from model.predict import make_prediction


def test_make_prediction(sample_input_data):
    # Given
    expected_no_predictions = len(sample_input_data)

    # When
    result = make_prediction(input_data=sample_input_data)

    # Then
    predictions = result.get("predictions")

    # Debe retornar una lista
    assert isinstance(predictions, list)

    # No debe haber errores de validación
    assert result.get("errors") is None

    # Debe predecir para todas las filas del dataset de test
    assert len(predictions) == expected_no_predictions

    # Cada predicción debe ser numérica (int o float)
    assert isinstance(predictions[0], (int, np.integer, float, np.floating))

    # Si tu variable COMPENSADO es 0/1, puedes dejar también esta línea:
    # assert set(predictions).issubset({0, 1})
