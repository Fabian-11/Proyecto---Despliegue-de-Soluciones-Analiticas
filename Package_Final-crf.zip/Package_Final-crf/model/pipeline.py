from feature_engine.selection import DropFeatures
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier

from model.config.core import config
from model.processing import features as pp

abandono_pipe = Pipeline(
    [
        # Si en algún punto quieres usar estos pasos, se pueden reactivar:
        # (
        #     "drop_features",
        #     DropFeatures(
        #         features_to_drop=config.model_config.temp_features
        #     ),
        # ),
        # (
        #     "mapper_qual",
        #     pp.Mapper(
        #         variables=config.model_config.qual_vars,
        #         mappings=config.model_config.qual_mappings,
        #     ),
        # ),

        # Escalador
        ("scaler", MinMaxScaler()),

        # Random Forest con los hiperparámetros definidos en config.yml
        (
            "Random Forest",
            RandomForestClassifier(
                n_estimators=config.model_config.n_estimators,
                max_depth=config.model_config.max_depth,
                min_samples_split=config.model_config.min_samples_split,
                min_samples_leaf=config.model_config.min_samples_leaf,
                class_weight=config.model_config.class_weight,
                random_state=config.model_config.random_state,
            ),
        ),
    ]
)
