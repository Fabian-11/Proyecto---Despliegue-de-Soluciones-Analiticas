from model.config.core import config
from model.pipeline import abandono_pipe
from model.processing.data_manager import load_dataset, save_pipeline


def run_training() -> None:
    """Train the Random Forest model for compensations."""

    # read training data
    data = load_dataset(file_name=config.app_config.train_data_file)

    # features (X) y target (y)
    X_train = data[config.model_config.features]
    y_train = data[config.model_config.target]

    # fit model
    abandono_pipe.fit(X_train, y_train)

    # persist trained model
    save_pipeline(pipeline_to_persist=abandono_pipe)


if __name__ == "__main__":
    run_training()
